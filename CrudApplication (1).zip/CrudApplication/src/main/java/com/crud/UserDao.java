package com.crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
	
	
	public static Connection getConnection()
	{
		Connection con = null ;
		
		try {
			//1. Register the driver 
			
			Class.forName("com.mysql.jdbc.Driver");
			
			//2.create connection 
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sample", "root", "1234");
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace(); 
		}
		return con ;
	}
	
	
	
	public static int save(User user)
	{
		int status = 0;
		try
		{
			Connection con = UserDao.getConnection();
			//3 statement 
			
			String query= "insert into user011(name,email,password,course) values(?,?,?,?) ";
			PreparedStatement pstmt = con.prepareStatement(query);
			
			pstmt.setString(1,user.getName());
			pstmt.setString(2, user.getEmail());
			pstmt.setString(3, user.getPassword());
			pstmt.setString(4, user.getCourse());
			
			//4 . execute query 
			status = pstmt.executeUpdate();
			
			con.close();
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return status;
		
	}
	
	
	public static List<User> getAllUsers()
	{
		
	List<User>  list = new ArrayList();
		
		
	try {
		
		Connection con = UserDao.getConnection();
		String query = "select * from user011";
		PreparedStatement ps = con.prepareStatement(query);
		
		ResultSet rs=ps.executeQuery();
		
		while(rs.next())
		{
			User user = new User();
			
			user.setId(rs.getInt(1));
			user.setName(rs.getString(2));
			user.setEmail(rs.getString(3));
			user.setPassword(rs.getString(4));
			user.setCourse(rs.getString(5));
			
			list.add(user);
			
		}
		
		con.close();
		
	}catch(Exception ex)
	{
		ex.printStackTrace();
		
	}
		return list;
	}
	
	
	public static int Update(User user)
	{
		int staus =0;
		
		try {
			Connection con = UserDao.getConnection();
			
			String query = "update user011 set name=?,email=?,password=?,course=? where id=?"; 
			
			PreparedStatement pstmt = con.prepareStatement(query);
			
			pstmt.setString(1, user.getName());
			pstmt.setString(2,user.getEmail());
			pstmt.setString(3, user.getPassword());
			pstmt.setString(4, user.getCourse());
			pstmt.setInt(5, user.getId());
			
			staus = pstmt.executeUpdate();
			
			con.close();
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return staus;
	}
	
	public static User getUserById(int sid)
	{
		User usr = new User();
		
		try
		{
			Connection con = UserDao.getConnection();
			
			String query = "select * from user011 where id=?"; 
			
			PreparedStatement pstmt = con.prepareStatement(query);
			
			pstmt.setInt(1,sid);
			
			ResultSet rs=pstmt.executeQuery();
			
			if(rs.next())
			{
				usr.setId(rs.getInt(1));
				usr.setName(rs.getString(2));
				usr.setEmail(rs.getString(3));
				usr.setPassword(rs.getString(4));
				usr.setCourse(rs.getString(5));
			}
			
			con.close();
		
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return usr;
	}
	
	
	
	public static int Delete(int id)
	{
		int staus = 0;
		
		try
		{
			Connection con = UserDao.getConnection();
			
			String query = "delete from user011 where id=?";
			
			
			PreparedStatement pst = con.prepareStatement(query);
			
			pst.setInt(1, id);
			
			staus =pst.executeUpdate(); 
			
			con.close();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return staus;
	}
	
	
}
