package com.crud;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/viewUsers")
public class ViewServlet extends HttpServlet {
	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException
	{
		PrintWriter out = resp.getWriter();
		
		out.println("<a href='index.html'>Add New User</a>");
		
		out.println("<h1>User List</h1>");
		
		
		List<User> user = UserDao.getAllUsers();

		
		out.println("<table border='1' width='100%'");
		
		out.println("<tr><th>Id</th><th>Name</th><th>Email</th><th>Password</th><th>Course</th><th>Edit</th><th>Delete</th></tr>");
		
		
		for(User u:user)
		{
			out.println("<tr> <td>"+u.getId()+"</td>"
					+ "<td>"+u.getName()+"</td>"
					+ "<td>"+u.getEmail()+"</td>"
					+ "<td>"+u.getPassword()+"</td>"
					+"<td>"+u.getCourse()+"</td>"
					+"<td><a href='EditServlet?id="+u.getId()+"'>Edit</a></td>"
					+ "<td><a href='DeleteServlet?id="+u.getId()+"'>Delete</a></td> </tr>");
			
		}
		out.println("</table>");
		
	}
	
	

}
