package com.crud;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/saveServlet")
public class SaveServlet extends HttpServlet {
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		
		PrintWriter out = resp.getWriter();
		
		String name = req.getParameter("user_name");
		String email = req.getParameter("user_email");
		String password = req.getParameter("user_password");
		String course = req.getParameter("course");
		
		
		User user = new User();
		
		user.setName(name);
		user.setEmail(email);
		user.setPassword(password);
		user.setCourse(course);
		
		int result = UserDao.save(user);
		
		
		if(result>0)
		{
			out.println("<h1 style='color:green'>Registration successfully</h1>");
			
			req.getRequestDispatcher("index.html").include(req, resp);
		}
		else
		{
			out.println("<h1 style='color:red'>Unable to save user</h1>");
		}
	}

}
