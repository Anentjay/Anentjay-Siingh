package com.crud;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/editServlet")
public class EditServlet2 extends HttpServlet {
	
	
	public void doPost(HttpServletRequest req , HttpServletResponse resp) throws IOException, ServletException
	{
		
		PrintWriter out = resp.getWriter();
		
		String uid = req.getParameter("id1");
		
		int id = Integer.parseInt(uid);
		
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String course = req.getParameter("course");
		
		
		User u1 = new User();
		
		u1.setId(id);
		u1.setName(name);
		u1.setEmail(email);
		u1.setPassword(password);
		u1.setCourse(course);
		
		int staus = UserDao.Update(u1);
		System.out.println(staus);
		if(staus >0)
		{
			out.println("<h1 style='color:green'>Updation successfully</h1>");
			req.getRequestDispatcher("viewUsers").include(req,resp);
			
		}
		else
		{
			out.println("<h3 style='red'>Sorry !! Unable to Edit user</h3>");
		}
		
		
	}
	

}
