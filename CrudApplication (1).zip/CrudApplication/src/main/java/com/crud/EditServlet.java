package com.crud;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	
	
	public void doGet(HttpServletRequest req , HttpServletResponse resp) throws IOException
	{
		
	PrintWriter out = resp.getWriter();	
	
	out.println("<h1>Update User Data</h1>");
	

	String sid = req.getParameter("id");
	
	int id = Integer.parseInt(sid);
	
	User user = UserDao.getUserById(id);
		
	out.println("<form action='editServlet' method='post'>");
	
	out.println("<table>");
	
	out.println("<tr><td></td><td><input type='hidden' name='id1' value="+user.getId()+" ></td></tr>");
	
	out.println("<tr><td>Name:</td> <td><input type='text' name='name' value="+user.getName()+" /></td></tr>");
	
	
	out.println("<tr><td>Email:</td> <td><input type='text' name='email' value="+user.getEmail()+" /></td></tr>");
	
	out.println("<tr><td>Password:</td> <td><input type='text' name='password' value="+user.getPassword()+" /></td></tr>");
	
	out.println("<tr><td>Course:</td><td>");
	
	out.println("<select name='course' style='width:150px'>");
	
	out.println("<option>Java</option>");
	out.println("<option>Python</option>");
	out.println("<option>React</option>");
	out.println("<option>Node</option>");
	out.println("<option>Other</option>");
	
	out.println("/select");
	out.println("</td></tr>");
	
	out.println("<tr><td colspan='2'><input type='submit' value='Edit'/></td></tr>");
	
	
	out.println("</table>");
	out.println("</form>");
	
	
	
	}
	

}
