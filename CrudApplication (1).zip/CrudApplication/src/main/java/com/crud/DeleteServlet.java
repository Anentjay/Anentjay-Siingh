package com.crud;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		
		PrintWriter out = resp.getWriter();
		
		String uId = req.getParameter("id");
		
		int id = Integer.parseInt(uId);
		
		UserDao.Delete(id);
		
		//resp.sendRedirect("viewUsers");
		
		out.println("<h1 style='color:green'>Delete successfully</h1>");
		
		req.getRequestDispatcher("viewUsers").include(req, resp);
		
	}
	

}
